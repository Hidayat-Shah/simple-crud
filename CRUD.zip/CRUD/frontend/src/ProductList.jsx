import React, { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

function ProductList() {
    const [products, setProducts] = useState([]);
    const [name, setName] = useState('');
    const [price, setPrice] = useState('');
    const [quantity, setQuantity] = useState('');
    const [newProduct, setNewProduct] = useState(null);
    const [editId, setEditId] = useState(null);
    const [editName, setEditName] = useState('');
    const [editPrice, setEditPrice] = useState('');
    const [editQuantity, setEditQuantity] = useState('');

    useEffect(() => {
        fetchProducts();
    }, []);

    const fetchProducts = async () => {
        const response = await axios.get('http://localhost:5000/products');
        setProducts(response.data);
    };

    const addProduct = async () => {
        if (!name || isNaN(price) || isNaN(quantity)) {
            alert('Please fill out all fields with valid data.');
            return;
        }
        const response = await axios.post('http://localhost:5000/products', { name, price, quantity });
        setNewProduct(response.data); // Highlight the newly added product
        fetchProducts();
        setName('');
        setPrice('');
        setQuantity('');
    };

    const editProduct = (product) => {
        setEditId(product.id);
        setEditName(product.name);
        setEditPrice(product.price);
        setEditQuantity(product.quantity);
    };

    const updateProduct = async () => {
        if (!editName || isNaN(editPrice) || isNaN(editQuantity)) {
            alert('Please fill out all fields with valid data.');
            return;
        }
        await axios.put(`http://localhost:5000/products/${editId}`, {
            name: editName,
            price: editPrice,
            quantity: editQuantity,
        });
        fetchProducts();
        cancelEdit();
    };

    const cancelEdit = () => {
        setEditId(null);
        setEditName('');
        setEditPrice('');
        setEditQuantity('');
    };

    const deleteProduct = async (id) => {
        await axios.delete(`http://localhost:5000/products/${id}`);
        fetchProducts();
    };

    return (
        <div className="container mt-4">
            <h1 className="text-center mb-4">Product List</h1>

            {/* Add Product Form */}
            <div className="mb-4">
                <h2>Add New Product</h2>
                <div className="row g-3">
                    <div className="col-md-4">
                        <input
                            type="text"
                            className="form-control"
                            placeholder="Name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                        />
                    </div>
                    <div className="col-md-4">
                        <input
                            type="number"
                            className="form-control"
                            placeholder="Price"
                            value={price}
                            onChange={(e) => setPrice(e.target.value)}
                        />
                    </div>
                    <div className="col-md-4">
                        <input
                            type="number"
                            className="form-control"
                            placeholder="Quantity"
                            value={quantity}
                            onChange={(e) => setQuantity(e.target.value)}
                        />
                    </div>
                </div>
                <button className="btn btn-success mt-3" onClick={addProduct}>
                    Add Product
                </button>
            </div>

            {/* Edit Product Form */}
            {editId && (
                <div className="mb-4">
                    <h2>Edit Product</h2>
                    <div className="row g-3">
                        <div className="col-md-4">
                            <input
                                type="text"
                                className="form-control"
                                placeholder="Name"
                                value={editName}
                                onChange={(e) => setEditName(e.target.value)}
                            />
                        </div>
                        <div className="col-md-4">
                            <input
                                type="number"
                                className="form-control"
                                placeholder="Price"
                                value={editPrice}
                                onChange={(e) => setEditPrice(e.target.value)}
                            />
                        </div>
                        <div className="col-md-4">
                            <input
                                type="number"
                                className="form-control"
                                placeholder="Quantity"
                                value={editQuantity}
                                onChange={(e) => setEditQuantity(e.target.value)}
                            />
                        </div>
                    </div>
                    <button className="btn btn-primary mt-3 me-2" onClick={updateProduct}>
                        Update Product
                    </button>
                    <button className="btn btn-secondary mt-3" onClick={cancelEdit}>
                        Cancel
                    </button>
                </div>
            )}

            {/* Product Cards */}
            <div className="row">
                {products.map((product) => (
                    <div key={product.id} className="col-md-4">
                        <div
                            className={`card mb-4 ${
                                newProduct?.id === product.id ? 'bg-warning' : ''
                            }`}
                        >
                            <div className="card-body">
                                <h5 className="card-title">{product.name}</h5>
                                <h6 className="card-subtitle mb-2 text-muted">
                                    ${product.price}
                                </h6>
                                <p className="card-text">Quantity: {product.quantity}</p>
                                <button
                                    className="btn btn-warning btn-sm me-2"
                                    onClick={() => editProduct(product)}
                                >
                                    Edit
                                </button>
                                <button
                                    className="btn btn-danger btn-sm"
                                    onClick={() => deleteProduct(product.id)}
                                >
                                    Delete
                                </button>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default ProductList;
