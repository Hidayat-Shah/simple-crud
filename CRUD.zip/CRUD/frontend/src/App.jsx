import React from 'react';
import ProductList from './ProductList';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
    return (
        <div className="container mt-4 bg-light">
            <div className="text-center mb-4">
                <h1 className="text-danger">Medical Store</h1>
                <p className="lead">Manage your products efficiently</p>
            </div>
            <ProductList />
        </div>
    );
}

export default App;

